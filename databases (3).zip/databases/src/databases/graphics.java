package databases;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.sql.ResultSet;

import javax.swing.JFrame;

public class graphics {

	private String[] q1;
	private String[] q2;
	private String[] q3;
	private String[] q4;
	private String[] q5;
	private String[] q6;
	private JFrame buttonWin;
	private int buttonWinWidth = 25;
	private int buttonWinHeight = 400;

	public graphics(String[] s1, String[] s2, String[] s3, String[] s4, String[] s5, String[] s6) {
		q1 = s1;
		q2 = s2;
		q3 = s3;
		q4 = s4;
		q5 = s5;
		q6 = s6;
	}

	// creates a window
	public void createWindow() throws IOException {
		int graphicHeight = 100;
		int windowWidth = 600;
		int windowHeight = 7 * graphicHeight;

		JFrame win = new JFrame();
		win.setBounds(25, 25, windowWidth, windowHeight);
		win.setTitle("NatureDatabase");
		Color c = new Color(156, 93, 82);
		win.getContentPane().setBackground(c);
		win.setLayout(null);
		win.setResizable(false);
		win.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		win.setVisible(true);

		JLabel title = new JLabel("Nature Database");
		title.setBounds(0, 10, 600, 100);
		title.setHorizontalAlignment(SwingConstants.CENTER);
		title.setFont(new Font("Serif", Font.BOLD, 50));
		win.add(title, 0);

		EventButton b1 = new EventButton(this);
		b1.setLocation(graphicHeight, graphicHeight * 1);
		b1.setSize(105, graphicHeight);
		b1.setText("Query1");
		win.add(b1, 0);

		EventButton b2 = new EventButton(this);
		b2.setLocation(graphicHeight, graphicHeight * 3);
		b2.setSize(105, graphicHeight);
		b2.setText("Query2");
		win.add(b2, 0);

		EventButton b3 = new EventButton(this);
		b3.setLocation(graphicHeight, graphicHeight * 5);
		b3.setSize(105, graphicHeight);
		b3.setText("Query3");
		win.add(b3, 0);

		EventButton b4 = new EventButton(this);
		b4.setLocation(graphicHeight * 4, graphicHeight * 1);
		b4.setSize(105, graphicHeight);
		b4.setText("Query4");
		win.add(b4, 0);

		EventButton b5 = new EventButton(this);
		b5.setLocation(graphicHeight * 4, graphicHeight * 3);
		b5.setSize(105, graphicHeight);
		b5.setText("Query5");
		win.add(b5, 0);

		EventButton b6 = new EventButton(this);
		b6.setLocation(graphicHeight * 4, graphicHeight * 5);
		b6.setSize(105, graphicHeight);
		b6.setText("Query6");
		win.add(b6, 0);

		win.repaint();
	}

	// sets window with results for query1
	public void setQuery1() {
		// set text q1 to win
		
		JLabel title = new JLabel("Q1: Select the second and third blog names sorted in ascending order");
		title.setBounds(0, 10, 700, 100);
		title.setHorizontalAlignment(SwingConstants.CENTER);
		buttonWin.add(title, 0);

		for (int i = 0; i < q1.length; i++) {
			if(q1[i] != null) {
			JLabel results = new JLabel(q1[i]);
			results.setBounds(0, 50, 700, 100* (i+1));
			results.setHorizontalAlignment(SwingConstants.CENTER);
			buttonWin.add(results, 0);
			}

		}

	}

	// sets window with results for query2
	public void setQuery2() {

		JLabel title = new JLabel("Q2: Find the species and characteristics of the most seen nature item in La Crosse");
		title.setBounds(0, 10, 700, 100);
		title.setHorizontalAlignment(SwingConstants.CENTER);
		buttonWin.add(title, 0);

		for (int i = 0; i < q2.length; i++) {
			if(q2[i] != null) {
			JLabel results = new JLabel(q2[i]);
			results.setBounds(0, 50, 700, 100* (i+1));
			results.setHorizontalAlignment(SwingConstants.CENTER);
			buttonWin.add(results, 0);
			}

		}

	}

	// sets window with results for query3
	public void setQuery3() {

		JLabel title = new JLabel("Q3: Select all users that are following a blog with the name 'naturerocks'");
		title.setBounds(0, 10, 700, 100);
		title.setHorizontalAlignment(SwingConstants.CENTER);
		buttonWin.add(title, 0);

		for (int i = 0; i < q3.length; i++) {
			if(q3[i] != null) {
			JLabel results = new JLabel(q3[i]);
			results.setBounds(0, 50, 700, 100* (i+1));
			results.setHorizontalAlignment(SwingConstants.CENTER);
			buttonWin.add(results, 0);
			}

		}
	}

	// sets window with results for query4
	public void setQuery4() {

		JLabel title = new JLabel("Q4: Select the PostID and Title where the post title begins with 'R'");
		title.setBounds(0, 10, 700, 100);
		title.setHorizontalAlignment(SwingConstants.CENTER);
		buttonWin.add(title, 0);

		for (int i = 0; i < q4.length; i++) {
			if(q4[i] != null) {
			JLabel results = new JLabel(q4[i]);
			results.setBounds(0, 50, 700, 100* (i+1));
			results.setHorizontalAlignment(SwingConstants.CENTER);
			buttonWin.add(results, 0);
			}

		}
	}

	// sets window with results for query5
	public void setQuery5() {

		JLabel title = new JLabel("Q5: Select PostID, Title, and Country where one characteristic is plant");
		title.setBounds(0, 10, 700, 100);
		title.setHorizontalAlignment(SwingConstants.CENTER);
		buttonWin.add(title, 0);

		for (int i = 0; i < q5.length; i++) {
			if(q5[i] != null) {
			JLabel results = new JLabel(q5[i]);
			results.setBounds(0, 50, 700, 100* (i+1));
			results.setHorizontalAlignment(SwingConstants.CENTER);
			buttonWin.add(results, 0);
			}

		}
	}

	// sets window with results for query6
	public void setQuery6() {

		JLabel title = new JLabel("Q6: Find the country with the most posts associated with it and a count of those posts");
		title.setBounds(0, 10, 700, 100);
		title.setHorizontalAlignment(SwingConstants.CENTER);
		buttonWin.add(title, 0);

		for (int i = 0; i < q6.length; i++) {
			if(q6[i] != null) {
			JLabel results = new JLabel(q6[i]);
			results.setBounds(0, 50, 700, 100* (i+1));
			results.setHorizontalAlignment(SwingConstants.CENTER);
			buttonWin.add(results, 0);
			}

		}
	}

	// when a button is pressed, creates a new window displaying the results of the
	// query ( chosen per the button )
	public void buttonPressed() {

		buttonWin = new JFrame();
		buttonWin.setBounds(25, 25, 700, 400);
		buttonWin.setTitle("Query Results");
		Color c = new Color(2, 99, 6);
		buttonWin.getContentPane().setBackground(c);
		buttonWin.setLayout(null);
		buttonWin.setResizable(false);
		buttonWin.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		buttonWin.setVisible(true);

	}

}
