package databases;

public class Follows {

	private String Username;
	private String Name;
	
	public Follows(String username, String name) {
		super();
		Username = username;
		Name = name;
	}

	@Override
	public String toString() {
		return "Follows [Username=" + Username + ", Name=" + Name + "]";
	}

	public String getUsername() {
		return Username;
	}

	public void setUsername(String username) {
		Username = username;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}
	
}
