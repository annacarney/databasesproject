package databases;

public class Contains {

	private String Name;
	private String Title;
	private String Date;
	
	public Contains(String name, String title, String date) {
		super();
		Name = name;
		Title = title;
		Date = date;
	}

	@Override
	public String toString() {
		return "Contains [Name=" + Name + ", Title=" + Title + ", Date=" + Date + "]";
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getTitle() {
		return Title;
	}

	public void setTitle(String title) {
		Title = title;
	}

	public String getDate() {
		return Date;
	}

	public void setDate(String date) {
		Date = date;
	}
}
