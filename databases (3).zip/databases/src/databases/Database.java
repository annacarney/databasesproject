package databases;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Database {

	Connection c = null;
	Statement stmt = null;
	
	Database(){
		//try to connect to database
		try {
			//gives access to the JDBC jar file
			Class.forName("org.sqlite.JDBC");
			//file directory to the SQLite file. Make sure this is correct!
			c = DriverManager.getConnection("jdbc:sqlite:/Users/arcar/OneDrive/Documents/Junior Year/Fall Semester/Databases - CS 364/NatureDatabase.db");
			System.out.println("Successful connection to database.");
		}catch(Exception e){
			System.out.println("Cannot connect");
		}
	}
	
	//SELECT * FROM Profile
	public String[] listProfile() {
		String[] s = new String[30];
		int index = 0;
		
		try {
			this.stmt = c.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM Profile");
			
			while(rs.next()) {
				int id = rs.getInt("ProfileID");
				String firstName = rs.getString("FirstName");
				String middleName = rs.getString("MiddleName");
				String lastName = rs.getString("LastName");
				String description = rs.getString("Description");
				
				s[index] = id + " " + firstName + " " + middleName + " " + lastName + " " + description + "\n";
				index++;
			}
			
		}catch(Exception e){
			System.out.println("Error in listProfile.");
		}
		return s;
	}
	
	public String[] listQ2( String query ) {
		String[] s = new String[30];
		int index = 0;
		
		try {
			this.stmt = c.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			
			while(rs.next()) {
				String species = rs.getString("Species");
				String chars = rs.getString("Characteristics");
				String count = rs.getString("seenCount");
				
				s[index] = species + " " + chars + " " + count;
				
				index++;
			}
			
		}catch(Exception e){
			System.out.println("Error in Q2.");
		}
		return s;
	}
	
	//closes DB connection
	public void closeConnection() {
		
		try {
			c.close();
			System.out.println("Connection ended successfully.");
		}catch(Exception e) {
			
		}
	
	}
	//this will take in any string given to the method and run it in the SQL file as if coding from there.
	public ResultSet runQuery(String query) throws SQLException {
		try {
			PreparedStatement st = c.prepareStatement(query);
			ResultSet results = st.executeQuery();
			return results;
		}catch(Exception e) {
			System.out.println("Error in executeQuery.");
		}
		return null;
	}

	public String[] listQ1(String query) {
		//returns blog name
		String[] s = new String[30];
		int index = 0;
		
		try {
			this.stmt = c.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			
			while(rs.next()) {
				String name = rs.getString("Name");
			
				s[index] = name;
				index++;
			}
			
		} catch(Exception e){
			System.out.println("Error in Q1.");
		}
		return s;
	}

	public String[] listQ3(String query) {
		//Q3 = 
		
				String[] s = new String[30];
				int index = 0;
				
				try {
					this.stmt = c.createStatement();
					ResultSet rs = stmt.executeQuery(query);
					
					while(rs.next()) {
						String name = rs.getString("Username");
						
						s[index] = name + " ";
						index++;
					}
					
				} catch(Exception e){
					System.out.println("Error in Q3.");
				}
				return s;
	}
	
	public String[] listQ4(String query) {
		//Q4 = 
		
				String[] s = new String[30];
				int index = 0;
				
				try {
					this.stmt = c.createStatement();
					ResultSet rs = stmt.executeQuery(query);
					
					while(rs.next()) {
						String PostID = rs.getString("PostID");
						String title = rs.getString("Title");
						//String count = rs.getString("count(*)");
						
						s[index] = PostID + " " + title;
						index++;
					}
					
				} catch(Exception e){
					System.out.println("Error in Q4.");
				}
				return s;
	}
	
	public String[] listQ5(String query) {
		//Q5 = 
		
				String[] s = new String[30];
				int index = 0;
				
				try {
					this.stmt = c.createStatement();
					ResultSet rs = stmt.executeQuery(query);
					
					//PostId, Title, Country
					while(rs.next()) {
						String m1 = rs.getString("PostID");
						String m2 = rs.getString("Title");
						String m3 = rs.getString("Country");
						
						s[index] = m1 + " " + m2 + " " + m3;
						index++;
					}
					
				} catch(Exception e){
					System.out.println("Error in Q5.");
				}
				return s;
	}
	
	public String[] listQ6(String query) {
		//Q6 = 
		
				String[] s = new String[30];
				int index = 0;
				
				try {
					this.stmt = c.createStatement();
					ResultSet rs = stmt.executeQuery(query);
					
					//MostPosts.Country, MostPosts.amount
					while(rs.next()) {
						String m1 = rs.getString("Country");
						String m2 = rs.getString("amount");
						
						s[index] = m1 + " " + m2;
						index++;
					}
					
				} catch(Exception e){
					System.out.println("Error in Q6.");
				}
				return s;
	}
	
}





