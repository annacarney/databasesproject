package databases;

public class Blog {

	private String Name;
	private String Description;
	
	public Blog(String name, String description) {
		super();
		Name = name;
		Description = description;
	}

	@Override
	public String toString() {
		return "Blog [Name=" + Name + ", Description=" + Description + "]";
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getDescription() {
		return Description;
	}

	public void setDescription(String description) {
		Description = description;
	}
	
	

}
