package databases;

public class Has {

	private int ProfileID;
	private String Username;
	
	public Has(int profileID, String username) {
		super();
		ProfileID = profileID;
		Username = username;
	}

	@Override
	public String toString() {
		return "Has [ProfileID=" + ProfileID + ", Username=" + Username + "]";
	}

	public int getProfileID() {
		return ProfileID;
	}

	public void setProfileID(int profileID) {
		ProfileID = profileID;
	}

	public String getUsername() {
		return Username;
	}

	public void setUsername(String username) {
		Username = username;
	}
	
	
}
