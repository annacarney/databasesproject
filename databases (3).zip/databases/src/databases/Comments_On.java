package databases;

public class Comments_On {

	private String Username;
	private String Title;
	private String Date;
	private String Timestamp;
	
	public Comments_On(String username, String title, String date, String timestamp) {
		super();
		Username = username;
		Title = title;
		Date = date;
		Timestamp = timestamp;
	}

	@Override
	public String toString() {
		return "Comments_On [Username=" + Username + ", Title=" + Title + ", Date=" + Date + ", Timestamp=" + Timestamp
				+ "]";
	}

	public String getUsername() {
		return Username;
	}

	public void setUsername(String username) {
		Username = username;
	}

	public String getTitle() {
		return Title;
	}

	public void setTitle(String title) {
		Title = title;
	}

	public String getDate() {
		return Date;
	}

	public void setDate(String date) {
		Date = date;
	}

	public String getTimestamp() {
		return Timestamp;
	}

	public void setTimestamp(String timestamp) {
		Timestamp = timestamp;
	}
}
