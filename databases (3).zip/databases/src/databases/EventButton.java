package databases;

import javax.swing.*;
	import java.awt.event.*;

	@SuppressWarnings( "serial" )
	public class EventButton extends JButton implements ActionListener
	{
	    private graphics graph;
	    
	    public EventButton( graphics g )
	    {
	        super();
	        addActionListener( this );
	        graph = g;
	    }
	    
	    /**
	     * post: If this button is pressed, the graphics calss method buttonPressed() is
	     * called to respond to the button press event.
	     *
	     * @param e : ActionEvent from associated objects
	     */
	    public void actionPerformed( ActionEvent e )
	    {	
	    	String button = e.getActionCommand();
	    	
	    	if( button.equals("Query1") ) {
	    		graph.buttonPressed();
	    		graph.setQuery1();
	            
	    	} else if( button.equals("Query2") ) {
	    		graph.buttonPressed();
	    		graph.setQuery2();
	    		
	    	} else if( button.equals("Query3") ) {
	    		graph.buttonPressed();
	    		graph.setQuery3();
	    		
	    	} else if( button.equals("Query4") ) {
	    		graph.buttonPressed();
	    		graph.setQuery4();
	    		
	    	} else if( button.equals("Query5") ) {
	    		graph.buttonPressed();
	    		graph.setQuery5();
	    		
	    	} else if( button.equals("Query6") ){	//query6
	    		graph.buttonPressed();
	    		graph.setQuery6();
	    		
	    	}
	    	
	    }
	}

