package databases;

public class Profile {

	private int ProfileID;
	private String FirstName;
	private String MiddleName;
	private String Lastname;
	private String Description;
	
	public Profile(int profileID, String firstName, String middleName, String lastname, String description) {
		super();
		ProfileID = profileID;
		FirstName = firstName;
		MiddleName = middleName;
		Lastname = lastname;
		Description = description;
	}

	@Override
	public String toString() {
		return "Profile [ProfileID=" + ProfileID + ", FirstName=" + FirstName + ", MiddleName=" + MiddleName
				+ ", Lastname=" + Lastname + ", Description=" + Description + "]";
	}

	public int getProfileID() {
		return ProfileID;
	}

	public void setProfileID(int profileID) {
		ProfileID = profileID;
	}

	public String getFirstName() {
		return FirstName;
	}

	public void setFirstName(String firstName) {
		FirstName = firstName;
	}

	public String getMiddleName() {
		return MiddleName;
	}

	public void setMiddleName(String middleName) {
		MiddleName = middleName;
	}

	public String getLastname() {
		return Lastname;
	}

	public void setLastname(String lastname) {
		Lastname = lastname;
	}

	public String getDescription() {
		return Description;
	}

	public void setDescription(String description) {
		Description = description;
	}
	
}
