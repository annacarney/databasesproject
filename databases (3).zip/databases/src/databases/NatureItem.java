package databases;

public class NatureItem {

	private int SpeciesID;
	private String Species;
	private String Characteristics;
	
	public NatureItem(int speciesID, String species, String characteristics) {
		super();
		SpeciesID = speciesID;
		Species = species;
		Characteristics = characteristics;
	}

	@Override
	public String toString() {
		return "NatureItem [SpeciesID=" + SpeciesID + ", Species=" + Species + ", Characteristics=" + Characteristics
				+ "]";
	}

	public int getSpeciesID() {
		return SpeciesID;
	}

	public void setSpeciesID(int speciesID) {
		SpeciesID = speciesID;
	}

	public String getSpecies() {
		return Species;
	}

	public void setSpecies(String species) {
		Species = species;
	}

	public String getCharacteristics() {
		return Characteristics;
	}

	public void setCharacteristics(String characteristics) {
		Characteristics = characteristics;
	}
	
	
}
