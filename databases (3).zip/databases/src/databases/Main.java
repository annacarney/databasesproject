package databases;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Main {

	public static void main(String[] args) throws SQLException, IOException {
		
		String query1 = "SELECT Blog.Name FROM Blog ORDER BY Blog.Name Asc LIMIT 2 OFFSET 1";			// Anna - group 2
		String query2 = "SELECT Species, Characteristics, max(laxCount) as seenCount FROM (SELECT Species, Characteristics, count(*) as laxCount FROM NatureItem NATURAL JOIN Affiliated NATURAL JOIN Post WHERE Post.City = 'La Crosse') ORDER BY seenCount Desc LIMIT 1"; 		//Anna - group 1
		String query3 = "SELECT User.Username FROM Follows NATURAL JOIN Blog NATURAL JOIN User WHERE Follows.Name IN ('naturerocks')"; 		//Anna - group 3
		
		String query4 = "SELECT PostID, Title FROM Post WHERE Title Like 'R%'";  		//garrett - group 1
		String query5 = "SELECT PostId, Title, Country FROM Post NATURAL JOIN Affiliated NATURAL JOIN NatureItem GROUP BY Country HAVING NatureItem.Characteristics LIKE '%plant%'"; 	//garrett - group 2
		String query6 = "SELECT MostPosts.Country, MostPosts.amount FROM (SELECT Country, Count(*) AS amount FROM Post GROUP BY Country ORDER BY count(*) Desc LIMIT 1 ) AS MostPosts"; 		//garrett - group 3	
		
		Database db = new Database();

		String[] q1 = db.listQ1(query1);
		String[] q2 = db.listQ2(query2);
		String[] q3 = db.listQ3(query3);
		
		String[] q4 = db.listQ4(query4);
		String[] q5 = db.listQ5(query5);
		String[] q6 = db.listQ6(query6);
		
		
		//display in GUI
		graphics g = new graphics(q1, q2, q3, q4, q5, q6);
		g.createWindow();
		
		//lists all profile tuples and attributes
		db.listProfile();
		
		db.closeConnection();
	}

}
