package databases;

public class Post {
	private String Title;
	private String Date;
	private String Photo;
	private String TextContent;
	private String City;
	private String State;
	private String Country;

	public Post(String title, String date, String photo, String textContent, String city, String state,
			String country) {
		super();
		Title = title;
		Date = date;
		Photo = photo;
		TextContent = textContent;
		City = city;
		State = state;
		Country = country;
	}

	@Override
	public String toString() {
		return "Post [Title=" + Title + ", Date=" + Date + ", Photo=" + Photo + ", TextContent=" + TextContent
				+ ", City=" + City + ", State=" + State + ", Country=" + Country + "]";
	}

	public String getTitle() {
		return Title;
	}

	public void setTitle(String title) {
		Title = title;
	}

	public String getDate() {
		return Date;
	}

	public void setDate(String date) {
		Date = date;
	}

	public String getPhoto() {
		return Photo;
	}

	public void setPhoto(String photo) {
		Photo = photo;
	}

	public String getTextContent() {
		return TextContent;
	}

	public void setTextContent(String textContent) {
		TextContent = textContent;
	}

	public String getCity() {
		return City;
	}

	public void setCity(String city) {
		City = city;
	}

	public String getState() {
		return State;
	}

	public void setState(String state) {
		State = state;
	}

	public String getCountry() {
		return Country;
	}

	public void setCountry(String country) {
		Country = country;
	}

	

}
