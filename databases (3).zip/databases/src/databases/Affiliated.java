package databases;

public class Affiliated {

	private String SpeciesID;
	private String Title;
	private String Date;
	
	public Affiliated(String speciesID, String title, String date) {
		super();
		SpeciesID = speciesID;
		Title = title;
		Date = date;
	}

	@Override
	public String toString() {
		return "Affiliated [SpeciesID=" + SpeciesID + ", Title=" + Title + ", Date=" + Date + "]";
	}

	public String getSpeciesID() {
		return SpeciesID;
	}

	public void setSpeciesID(String speciesID) {
		SpeciesID = speciesID;
	}

	public String getTitle() {
		return Title;
	}

	public void setTitle(String title) {
		Title = title;
	}

	public String getDate() {
		return Date;
	}

	public void setDate(String date) {
		Date = date;
	}
}
